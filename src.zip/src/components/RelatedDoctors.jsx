import React from 'react'

const RelatedDoctors = () => {
  return (
    <div>
      
    </div>
  )
}

export default RelatedDoctors
